extends Node3D
const Plants=preload("res://layout/plantings.gd")
const Display=preload("res://presentation/player_plants.gd")
const Space=preload("res://scenes/environment/animal_space.gd")
const IslandSpace=preload("res://layout/island_space.gd")
var main: Node3D
var environment: Node3D
var display: Node3D
var message: String=""
var _original: Node3D
var _obstacles: Dictionary={}
var _index:=IslandSpace.new()
var _paths:=IslandSpace.new()
var _path_source: Array=[]
var _entry_checks: Dictionary={}
var _habitat: Dictionary={}
var _accepted: bool=false
var _original_shore: Node3D
var _shore: Node3D
var _shown: Array=[]

func configure(scene: Node3D) -> void:
	main=scene;environment=main.get_node("Environment");_original=environment.get_node("PlayerPlants")
	# Land is fixed for this plant-only preview; each terrain edit creates a
	# fresh preview. Dynamic animals and arriving paths are checked separately.
	_habitat=Plants.habitat_geometry(environment.plan)
	_obstacles=environment.layout_obstacles.duplicate(true)
	for key: String in _obstacles.keys():
		if key.begins_with("player_plant_"): _obstacles.erase(key)
	for node: Node3D in environment._shore_sources:
		if node.has_meta("bank_role"): continue
		_obstacles["water_%d"%node.get_instance_id()]=Space.cached_footprint(node,-.55,.55)
	_obstacles["bridge"]=Space.cached_footprint(environment.get_bridge(),environment.plan.ground_height-.08,environment.plan.ground_height+.75)
	_obstacles["boat"]=Space.cached_footprint(environment.get_node("CoveredBoat"),-.55,.65)
	_obstacles.merge(main.decoration_layout.ground_footprints())
	for key: String in _obstacles: _index.add(key,_obstacles[key])
	_sync_paths()
	display=Display.new();add_child(display);display.low_detail=main.focus_detail._quality=="low"
	_original_shore=environment.get_node_or_null("NewShorePlants")
	if is_instance_valid(_original_shore): _original_shore.hide()
	_original.hide()

func _sync_paths() -> void:
	if _path_source==environment.plan.paths: return
	_path_source=environment.plan.paths.duplicate(true);_paths=IslandSpace.new()
	_entry_checks.clear()
	for route_index: int in environment.plan.paths.size():
		var route: PackedVector3Array=environment.plan.paths[route_index]
		for i: int in range(1,route.size()):
			var a:=Vector2(route[i-1].x,route[i-1].z);var b:=Vector2(route[i].x,route[i].z)
			var side:=Vector2(-(b-a).y,(b-a).x).normalized()*.34
			_paths.add("%d_%d"%[route_index,i],PackedVector2Array([a-side,b-side,b+side,a+side]))

func entry_issue(entry: Dictionary, check_animals: bool=true) -> String:
	_sync_paths()
	# Terrain and scene feet belong to this preview session. Pose/path changes
	# invalidate static checks; moving animals are always checked again below.
	var previous: Dictionary=_entry_checks.get(entry.id,{})
	if previous.get("entry",{})!=entry:
		previous={"entry":entry.duplicate(true),"message":_static_entry_issue(entry)}
		_entry_checks[entry.id]=previous
	if not previous.message.is_empty(): return previous.message
	if check_animals:
		var polygon: PackedVector2Array=Plants.footprint(entry)
		var bounds:=Rect2(polygon[0],Vector2.ZERO)
		for point: Vector2 in polygon: bounds=bounds.expand(point)
		for bird: Dictionary in environment.get_node("CourtyardAnimals").birds:
			# Plant feet are rotated rectangles; twice the clearance also encloses
			# their offset corners. Only nearby birds need the exact polygon check.
			if not bounds.grow((bird.radius+.15)*2).has_point(bird.position): continue
			for expanded: PackedVector2Array in Geometry2D.offset_polygon(polygon,bird.radius+.15):
				if Geometry2D.is_point_in_polygon(bird.position,expanded): return "这里有动物，请等它走开再布置。"
	return ""

func _static_entry_issue(entry: Dictionary) -> String:
	var issue: String=Plants.habitat_issue(entry,_habitat)
	if not issue.is_empty(): return issue
	var polygon: PackedVector2Array=Plants.footprint(entry)
	if not _index.collisions(polygon).is_empty(): return "请避开景物、桥头和码头。"
	if not _paths.collisions(polygon).is_empty(): return "请为道路留出空间。"
	return ""

func update(plan: RefCounted) -> void:
	message=""
	if _shown!=plan.plants or not is_instance_valid(_shore):
		display.update(plan.plants);environment.fit_player_dressing(plan)
		if is_instance_valid(_original_shore):
			if is_instance_valid(_shore): _shore.free()
			_shore=preload("res://presentation/shore_dressing.gd").plants(plan);add_child(_shore)
		_shown=plan.plants.duplicate(true)
	var occupied: Dictionary=Plants.index_entries(plan.plants)
	var present: Dictionary={}
	for entry: Dictionary in plan.plants: present[entry.id]=true
	for id: int in _entry_checks.keys():
		if not present.has(id): _entry_checks.erase(id)
	for entry: Dictionary in plan.plants:
		if entry in environment.plan.plants: continue
		message=entry_issue(entry)
		if not message.is_empty(): break
		if Plants.too_close(entry,occupied,.001):
			message="这里已有手植植物，请留出一点间距。";return
	if not message.is_empty(): return
	var animals: Node3D=environment.get_node("CourtyardAnimals")
	var added: Array[PackedVector2Array]=[]
	for entry: Dictionary in plan.plants:
		if entry not in environment.plan.plants: added.append(Plants.footprint(entry))
	var shapes: Array[PackedVector2Array]=[]
	for child: Node in environment.get_children():
		if child is Node3D and child.name!="PlayerPlants": shapes.append_array(animals.water_shapes(child,plan))
	shapes.append_array(Plants.footprints(plan.plants).values())
	message=preload("res://layout/bridge_passage.gd").water_issue(plan,shapes)
	if not message.is_empty(): return
	for kind: String in ["duck","goose"]:
		message=preload("res://layout/flock_layout.gd").added_obstacle_issue(plan,kind,animals.water,added)
		if not message.is_empty(): return

func accept(plan: RefCounted) -> void:
	_accepted=true;environment.remove_child(_original);_original.queue_free()
	display.reparent(environment);display.name="PlayerPlants"
	if is_instance_valid(_original_shore):
		environment.remove_child(_original_shore);_original_shore.queue_free()
		_shore.reparent(environment);_shore.name="NewShorePlants"
	for key: String in environment.layout_obstacles.keys():
		if key.begins_with("player_plant_"): environment.layout_obstacles.erase(key)
	environment.layout_obstacles.merge(Plants.footprints(plan.plants))
	plan.paths=environment.plan.paths.duplicate();plan.garden_fences=environment.plan.garden_fences.duplicate(true);plan.fences=environment.plan.fences.duplicate(true)
	environment.plan=plan;environment.get_node("LivingDetails").plan=plan;main.courtyard_plan=plan;main.farm.plan=plan
	environment.fit_player_dressing(plan,true)

func _exit_tree() -> void:
	if not _accepted:
		if is_instance_valid(_original): _original.show()
		if is_instance_valid(_original_shore): _original_shore.show()
		if is_instance_valid(environment): environment.fit_player_dressing(environment.plan)
