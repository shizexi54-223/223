extends "res://scenes/procedural_lab/procedural_lab.gd"
const RailingKit = preload("res://scenes/procedural_lab/railing_kit.gd")
const TreeKit = preload("res://scenes/procedural_lab/tree_kit.gd")
const HouseKit = preload("res://scenes/procedural_lab/house_kit.gd")
const RailingBrush = preload("res://scenes/procedural_lab/railing_brush.gd")
var kind: String = "railing"
var kind_picker := OptionButton.new()
var parameter_box: VBoxContainer
var compare_check := CheckButton.new()
var export_button := Button.new()
var generation_ms: float = 0
var wind_check := CheckButton.new()
var joint_view: bool = false
var draw_button := Button.new()
var erase_button := Button.new()
var undo_button := Button.new()
var preset_button := Button.new()
var help := Label.new()
var brush: Node3D
var drawn_paths: Array = []
var custom_railing: bool = false
var edit_history: Array[Dictionary] = []

func _ready() -> void:
	# Island-only controls are constructed by the inherited script, but never used
	# or parented in this scene. Release them before creating the component panel.
	for unused: Control in [overlay_check,focus_bridge,focus_rack,preset_picker]: unused.free()
	DisplayServer.window_set_title("构件生成研究室 · 我有一片田")
	Engine.max_fps = 60
	AudioServer.set_bus_mute(0,true)
	if "--dev-preview" in OS.get_cmdline_user_args():
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
	get_viewport().size_changed.connect(_resize)
	_resize()
	_setup_environment()
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--component=") and argument.get_slice("=",1) in ["railing","rack","tree","house"]:
			kind=argument.get_slice("=",1)
	_setup_ui()
	brush=RailingBrush.new(); brush.lab=self; add_child(brush)
	await regenerate()
	await RenderingServer.frame_post_draw
	print("COMPONENT_LAB_READY kind=%s seed=%s"%[kind,current_plan.seed])
	print("LAB_RENDER_SETTINGS scaling_mode=%d scale=%.3f msaa=%d taa=%s fsr_sharpness=%.2f" % [get_viewport().scaling_3d_mode,get_viewport().scaling_3d_scale,get_viewport().msaa_3d,get_viewport().use_taa,get_viewport().fsr_sharpness])
	print("DEV_PREVIEW_READY screen=%d mode=%d size=%s"%[DisplayServer.window_get_current_screen(),DisplayServer.window_get_mode(),DisplayServer.window_get_size()])

func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var screen := Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.theme = FarmTheme.create()
	layer.add_child(screen)
	panel = PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	panel.offset_left=20; panel.offset_top=20; panel.offset_right=334; panel.offset_bottom=-20
	screen.add_child(panel)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation",12)
	scroll.add_child(column)
	var title := Label.new()
	title.text="构件生成研究室"
	title.add_theme_font_size_override("font_size",28)
	column.add_child(title)
	for text: String in ["木栏杆","竹架","桂花树","江南民居"]: kind_picker.add_item(text)
	kind_picker.select(["railing","rack","tree","house"].find(kind))
	column.add_child(kind_picker)
	FarmTheme.configure_option(kind_picker)
	kind_picker.item_selected.connect(_select_kind)
	seed_input.text="水乡木作-26"; seed_input.max_length=64
	seed_input.placeholder_text="输入文字或数字种子"
	seed_input.custom_minimum_size.y=38
	seed_input.add_theme_color_override("font_color",Color("353f30"))
	seed_input.add_theme_stylebox_override("normal",FarmTheme.paper(Color("f0eee2"),6))
	column.add_child(seed_input)
	seed_input.text_changed.connect(func(_value: String) -> void: _dirty())
	seed_input.text_submitted.connect(func(_value: String) -> void: regenerate())
	parameter_box=VBoxContainer.new()
	parameter_box.add_theme_constant_override("separation",10)
	column.add_child(parameter_box)
	_populate_parameters()
	var actions := HBoxContainer.new()
	column.add_child(actions)
	generate_button.text="重新生成"
	generate_button.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	generate_button.pressed.connect(regenerate)
	actions.add_child(generate_button)
	var random_button := Button.new()
	random_button.text="换个种子"
	random_button.pressed.connect(func() -> void:
		seed_input.text=str(randi_range(100000,99999999))
		regenerate())
	actions.add_child(random_button)
	compare_check.text="并排对比三种结构"
	compare_check.toggled.connect(func(_value: bool) -> void: regenerate())
	column.add_child(compare_check)
	wind_check.text="枝叶随风轻动"; wind_check.button_pressed=true
	wind_check.visible=false
	wind_check.toggled.connect(_set_wind)
	column.add_child(wind_check)
	export_button.text="复制当前生成参数"
	export_button.pressed.connect(func() -> void:
		DisplayServer.clipboard_set(JSON.stringify({"version":1,"kind":kind,"seed":current_plan.seed,"parameters":current_plan.settings,"comparison":current_plan.comparison}))
		status.text="已复制当前画面的种子与参数")
	column.add_child(export_button)
	for label: Label in [status,statistics]:
		label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		label.add_theme_font_size_override("font_size",16)
		column.add_child(label)
	var top := HFlowContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.offset_left=356; top.offset_top=22; top.offset_right=-20; top.offset_bottom=64
	screen.add_child(top)
	for item: Array in [["完整观察","all"],["近看接头","joint"],["转到背面","reverse"]]:
		var button := Button.new()
		button.text=item[0]
		button.pressed.connect(focus.bind(item[1]))
		top.add_child(button)
	draw_button.text="画栏杆"; draw_button.toggle_mode=true
	draw_button.toggled.connect(_set_drawing)
	top.add_child(draw_button)
	erase_button.text="擦除"; erase_button.toggle_mode=true
	erase_button.toggled.connect(func(enabled: bool) -> void: _set_tool("erase" if enabled else ""))
	top.add_child(erase_button)
	undo_button.text="撤销"; undo_button.disabled=true
	undo_button.pressed.connect(undo_edit)
	top.add_child(undo_button)
	preset_button.text="恢复预设"
	preset_button.pressed.connect(func() -> void:
		brush.cancel(); drawn_paths.clear(); custom_railing=false; edit_history.clear()
		draw_button.set_pressed_no_signal(false); erase_button.set_pressed_no_signal(false); brush.enabled=false
		_update_drawing_controls(); regenerate())
	top.add_child(preset_button)
	help.text="左键旋转  ·  右键 / 中键平移  ·  滚轮缩放  ·  Esc 退出"
	help.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	help.offset_left=356; help.offset_top=-42; help.offset_bottom=-12
	help.add_theme_font_size_override("font_size",17)
	screen.add_child(help)
	for button: Node in screen.find_children("*","Button",true,false): FarmTheme.pointer_focus(button)

func _populate_parameters() -> void:
	for child: Node in parameter_box.get_children():
		parameter_box.remove_child(child); child.queue_free()
	controls.clear()
	if kind == "house":
		_slider(parameter_box,"bays","开间数",2,3,1,3)
		_slider(parameter_box,"depth","进深",3.6,5.2,.2,4.2," 米")
		_slider(parameter_box,"height","层高",2.4,3.2,.1,2.7," 米")
		_slider(parameter_box,"pitch","屋顶坡度",22,38,1,30,"°")
		_slider(parameter_box,"porch","门廊：无 / 有",0,1,1,1)
		_slider(parameter_box,"openings","门窗：居中 / 靠左 / 靠右",0,2,1,0)
		_named_choice("porch","门廊",["无","有"])
		_named_choice("openings","大门位置",["居中","靠左","靠右"])
		return
	if kind == "tree":
		_slider(parameter_box,"height","树高",3,5.8,.2,4.2," 米")
		_slider(parameter_box,"spread","冠幅",2.8,6,.2,4.4," 米")
		_slider(parameter_box,"density","树冠疏密",0,1,.05,.55)
		_slider(parameter_box,"bias","偏冠程度",0,.7,.05,.25)
		return
	_slider(parameter_box,"length","长度",2.4,8,.2,5.4," 米")
	if kind == "railing":
		_slider(parameter_box,"height","栏高",.7,1.4,.05,1.05," 米")
		_slider(parameter_box,"path","走向：直线 / 转角 / 折线",0,2,1,1)
	else:
		_slider(parameter_box,"height","架高",1.6,2.8,.1,2.1," 米")
		_slider(parameter_box,"width","架宽",1,3,.1,1.8," 米")
	_slider(parameter_box,"bay","最大开间",.8,1.8,.1,1.35," 米")
	_slider(parameter_box,"slope","地面坡度",-.18,.18,.02,0)

func _select_kind(index: int) -> void:
	brush.cancel(); brush.enabled=false
	draw_button.set_pressed_no_signal(false)
	erase_button.set_pressed_no_signal(false)
	kind=["railing","rack","tree","house"][index]
	kind_picker.select(index)
	wind_check.visible=kind=="tree"
	_populate_parameters()
	_update_drawing_controls()
	regenerate()

func _set_drawing(enabled: bool) -> void:
	_set_tool("draw" if enabled else "")

func _set_tool(tool: String) -> void:
	brush.cancel(); brush.enabled=not tool.is_empty(); brush.erasing=tool=="erase"; dragging=0
	draw_button.set_pressed_no_signal(tool=="draw")
	erase_button.set_pressed_no_signal(tool=="erase")
	if brush.enabled: compare_check.set_pressed_no_signal(false)
	_update_drawing_controls()
	await regenerate()
	if brush.enabled: status.text="擦除已启用" if brush.erasing else "画笔已启用"

func _update_drawing_controls() -> void:
	var custom: bool = kind=="railing" and (brush.enabled or custom_railing)
	draw_button.visible=kind=="railing"; preset_button.visible=kind=="railing"
	erase_button.visible=kind=="railing"; undo_button.visible=kind=="railing"
	draw_button.text="结束画线" if brush.enabled and not brush.erasing else "画栏杆"
	erase_button.text="结束擦除" if brush.enabled and brush.erasing else "擦除"
	undo_button.disabled=edit_history.is_empty()
	preset_button.disabled=not custom
	compare_check.disabled=custom
	if custom: compare_check.set_pressed_no_signal(false)
	for key: String in ["length","path"]:
		if controls.has(key): controls[key].get_parent().visible=not custom
	help.text=("左键擦除" if brush.erasing else "左键画线")+"  ·  右键 / 中键平移  ·  滚轮缩放  ·  Esc 取消" if brush.enabled else "左键旋转  ·  右键 / 中键平移  ·  滚轮缩放  ·  Esc 退出"

func accept_paths(paths: Array) -> void:
	edit_history.append({"paths":drawn_paths.duplicate(true),"custom":custom_railing})
	if edit_history.size()>20: edit_history.pop_front()
	drawn_paths=paths; custom_railing=true
	_update_drawing_controls()
	await regenerate(false)
	status.text="已擦除" if brush.erasing else "已更新栏杆"

func undo_edit() -> void:
	if busy or edit_history.is_empty(): return
	brush.cancel()
	var previous: Dictionary = edit_history.pop_back()
	drawn_paths=previous.paths; custom_railing=previous.custom
	_update_drawing_controls()
	await regenerate(false)
	status.text="已撤销上一步"

func _input(event: InputEvent) -> void:
	if is_instance_valid(brush) and brush.handle_input(event):
		get_viewport().set_input_as_handled()
		return
	super._input(event)

func _unhandled_input(event: InputEvent) -> void:
	if is_instance_valid(brush) and brush.handle_unhandled(event):
		get_viewport().set_input_as_handled()
		return
	super._unhandled_input(event)

func _notification(what: int) -> void:
	super._notification(what)
	if what in [NOTIFICATION_WM_WINDOW_FOCUS_OUT,NOTIFICATION_WM_MOUSE_EXIT] and is_instance_valid(brush):
		brush.cancel()

func _resize() -> void:
	if is_instance_valid(brush): brush.cancel()
	super._resize()

func _named_choice(key: String,title: String,choices: Array[String]) -> void:
	var slider: HSlider=controls[key]
	var label: Label=slider.get_parent().get_child(0)
	var update := func(v: float) -> void: label.text=title+"   "+choices[int(v)]
	slider.value_changed.connect(update)
	update.call(slider.value)

func _dirty() -> void:
	status.text="调整后点击「重新生成」"

func regenerate(reset_camera: bool=true) -> void:
	if busy: return
	if seed_input.text.strip_edges().is_empty():
		status.text="请输入文字或数字种子"
		return
	brush.cancel()
	busy=true; dragging=0; generate_button.disabled=true
	status.text="正在组合构件…"
	await get_tree().process_frame
	var start: int=Time.get_ticks_usec()
	var options: Dictionary={}
	for key: String in controls: options[key]=controls[key].value
	if kind=="railing" and custom_railing: options.paths=drawn_paths
	var data: Dictionary=_plan(options)
	if data.has("error"):
		status.text=data.error; busy=false; generate_button.disabled=false
		return
	data.comparison=[]
	var next := Node3D.new()
	var count: int=3 if compare_check.button_pressed else 1
	for i: int in count:
		var sample: Dictionary=data
		if count == 3:
			var variant: Dictionary=options.duplicate()
			if kind == "railing": variant.path=i
			elif kind == "rack":
				variant.length=[2.8,4.6,6.8][i]; variant.width=[1.2,1.8,2.6][i]
			elif kind=="tree":
				variant.height=[5.4,3.2,4.2][i]; variant.spread=[3.0,4.6,5.8][i]
				variant.density=[.25,.8,.55][i]; variant.bias=[0,.15,.7][i]
			else:
				variant.bays=[2,3,3][i]; variant.depth=[3.6,4.2,5.2][i]
				variant.height=[2.4,2.7,3.2][i]; variant.pitch=[24,30,38][i]
				variant.porch=[0,1,1][i]; variant.openings=[0,1,2][i]
			sample=_plan(variant)
			data.comparison.append(sample.settings)
		var holder := Node3D.new()
		holder.position.z=(i-1)*({"tree":8.0,"house":10.0}.get(kind,6.0)) if count == 3 else 0.0
		holder.position.y=_stage_height(sample.settings)
		if kind=="house" and count==3: holder.rotation.y=PI*.5
		holder.add_child(_build(sample))
		holder.add_child(_ground(sample.settings))
		if count == 3:
			var label := Label3D.new()
			label.font=preload("res://art/ui/fonts/汇文明朝体.ttf")
			label.text={"railing":["直线","转角","折线"],"rack":["短窄架","标准架","宽长架"],"tree":["高窄冠","低圆冠","偏冠"],"house":["两间小屋","三间廊屋","深进大屋"]}[kind][i]
			label.font_size=48; label.pixel_size=.007
			label.position=Vector3(0,(HouseKit.roof_y(0,sample.settings) if kind=="house" else sample.settings.height)+.55,0)
			label.billboard=BaseMaterial3D.BILLBOARD_ENABLED
			label.alpha_cut=Label3D.ALPHA_CUT_DISCARD
			label.modulate=Color("353f30"); label.outline_modulate=Color("ecebd8")
			holder.add_child(label)
		next.add_child(holder)
	add_child(next)
	if is_instance_valid(world):
		remove_child(world); world.queue_free()
	world=next; current_plan=data
	generation_ms=(Time.get_ticks_usec()-start)/1000.0
	if reset_camera: focus("all")
	status.text="已生成 · %.0f 毫秒 · 种子 %s"%[generation_ms,data.seed]
	statistics.text="%d 根立柱 · %d 段独立围栏"%[data.points.size(),data.runs.size()] if kind=="railing" and custom_railing else "%d 组结构"%count
	_set_wind(wind_check.button_pressed)
	busy=false; generate_button.disabled=false

func _plan(options: Dictionary) -> Dictionary:
	if kind=="tree": return TreeKit.plan(seed_input.text,options)
	if kind=="house": return HouseKit.plan(seed_input.text,options)
	return RailingKit.plan(seed_input.text,options,kind)

func _build(sample: Dictionary) -> Node3D:
	if kind=="tree": return TreeKit.build(sample)
	if kind=="house": return HouseKit.build(sample)
	return RailingKit.build(sample)

func _set_wind(enabled: bool) -> void:
	if not is_instance_valid(world): return
	for node: Node in world.find_children("tree_cluster*","MultiMeshInstance3D",true,false):
		node.set_instance_shader_parameter("wind_motion",Vector4(.035,.18,0,.006) if enabled else Vector4.ZERO)
		node.set_instance_shader_parameter("wind_authored_bend",.018 if enabled else 0.0)

func _ground(p: Dictionary) -> MeshInstance3D:
	var mesh := PlaneMesh.new()
	if _drawing_stage(): mesh.size=Vector2.ONE*RailingBrush.EXTENT*2
	elif kind=="tree": mesh.size=Vector2.ONE*(p.spread+1)
	elif kind=="house": mesh.size=Vector2(p.bays*HouseKit.BAY+2,p.depth+p.porch+2.4)
	else: mesh.size=Vector2(p.length+1.4,maxf(p.width+1.2,p.length*.7))
	var node := MeshInstance3D.new()
	node.mesh=mesh
	# Shear the stage to the exact same height function used by the feet.
	node.basis=Basis(Vector3(1,p.get("slope",0),0),Vector3.UP,Vector3.BACK)
	node.position.y=.13
	var material := ShaderMaterial.new()
	material.shader=preload("res://scenes/environment/pigment.gdshader")
	material.set_shader_parameter("base_color",Color("918566"))
	material.set_shader_parameter("ground_treatment",1.0)
	node.material_override=material
	return node

func _stage_height(p: Dictionary) -> float:
	if _drawing_stage(): return absf(p.slope)*RailingBrush.EXTENT
	return 0.0 if kind in ["tree","house"] else absf(p.slope)*(p.length+1.4)*.5

func _drawing_stage() -> bool:
	return kind=="railing" and is_instance_valid(brush) and (brush.enabled or custom_railing)

func focus(mode: String) -> void:
	if current_plan.is_empty(): return
	if kind=="railing" and current_plan.points.is_empty() and mode=="joint": mode="all"
	if mode == "reverse":
		yaw+=PI
		if kind=="house" and joint_view:
			target.x=-target.x; target.z=-target.z
	else:
		joint_view=mode=="joint"
		var p: Dictionary=current_plan.settings
		if mode == "joint":
			if kind in ["tree","house"]:
				target=current_plan.joint+Vector3.UP*(-.25 if kind=="house" else .5)
				desired_distance=5
			else:
				var at: Vector3=current_plan.points[mini(1,current_plan.points.size()-1)]
				target=at+Vector3(0,_stage_height(p)+p.height*.75,p.width*.41 if kind == "rack" else 0)
				desired_distance=3.5
			pitch=.30
			if kind=="house":
				yaw=.8; pitch=.08
				if compare_check.button_pressed:
					target=Basis(Vector3.UP,PI*.5)*target; yaw+=PI*.5
		else:
			target=Vector3(0,_stage_height(p)+p.height*.4,0)
			if kind=="house": target.y=HouseKit.roof_y(0,p)*.42
			if compare_check.button_pressed: desired_distance={"tree":29,"house":38}.get(kind,26)
			elif kind=="house": desired_distance=17
			else: desired_distance=maxf(9,p.height*2.2 if kind=="tree" else p.length*1.75)
			pitch=.28 if kind in ["tree","house"] and compare_check.button_pressed else .55
			if kind=="house" and not compare_check.button_pressed: pitch=.43
			yaw=PI*.5 if kind in ["tree","house"] and compare_check.button_pressed else .65
			if _drawing_stage():
				desired_distance=25; pitch=1.08; yaw=0
		distance=desired_distance
	_update_camera()
