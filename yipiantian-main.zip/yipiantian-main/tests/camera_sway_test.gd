extends SceneTree

var failures: Array[String] = []
var output: String

func _initialize() -> void:
	_run.call_deferred()

func expect(ok: bool, message: String) -> void:
	if not ok: failures.append(message)

func _run() -> void:
	output = ProjectSettings.globalize_path("res://../.local/verification/camera-sway")
	DirAccess.make_dir_recursive_absolute(output)
	root.size = Vector2i(1600,900)
	var scene: Node3D = load("res://scenes/main.tscn").instantiate()
	scene.store = load("res://farm/farm_store.gd").new(output.path_join("farm"))
	scene.settings_store = load("res://settings/settings_store.gd").new(output.path_join("preferences-%d" % Time.get_ticks_usec()))
	root.add_child(scene)
	await create_timer(1).timeout
	var camera: FarmCamera = scene.camera
	camera.sway_motion._noise.seed = 42
	camera.set_process(false)
	var original_view: Vector3 = camera.view
	var original_point: Vector3 = camera.focus_point
	camera.configure_sway(true, 2.0)
	for frame: int in 119: camera._process(1.0/60.0)
	expect(camera.h_offset == 0 and camera.v_offset == 0, "No sway before idle deadline")
	var largest: float = 0
	var projected_min := camera.unproject_position(original_point)
	var projected_max := projected_min
	for frame: int in 1200:
		camera._process(1.0/60.0)
		largest = maxf(largest, Vector2(camera.h_offset,camera.v_offset).length())
		var projected := camera.unproject_position(original_point)
		projected_min = projected_min.min(projected)
		projected_max = projected_max.max(projected)
	expect(largest > .04 and largest < .16, "Idle motion exists and stays subtle")
	expect(projected_max.distance_to(projected_min) > 4.0 and projected_max.distance_to(projected_min) < 22.0, "Sway visibly moves the rendered framing by a few pixels")
	expect(camera.view == original_view and camera.focus_point == original_point, "Sway does not contaminate remembered framing")
	var before := Vector2(camera.h_offset,camera.v_offset)
	var wheel := InputEventMouseButton.new()
	wheel.button_index = MOUSE_BUTTON_WHEEL_UP
	wheel.pressed = true
	root.push_input(wheel)
	expect(Vector2(camera.h_offset,camera.v_offset) == before, "Input does not snap sway offset")
	camera.zoom(-2)
	camera.drag(Vector2(12,5), true)
	var panned: Vector3 = camera.focus_point
	for frame: int in 110: camera._process(1.0/60.0)
	expect(camera.focus_point == panned and camera.view.z < original_view.z - 1.9, "Pan preserves wheel distance and its own target")
	expect(Vector2(camera.h_offset,camera.v_offset).length() < .0001, "Interaction fades sway away")
	scene._open_menu()
	scene.game_menu._sway.button_pressed = true
	scene.game_menu._sway_delay.value = 0
	expect(camera.sway_enabled and camera.sway_idle_seconds == 0, "Actual settings controls apply zero-delay sway")
	for frame: int in 600: camera._process(1.0/60.0)
	var hover_motion: float = 0
	for frame: int in 600:
		var hover := InputEventMouseMotion.new()
		hover.relative = Vector2(1,0)
		root.push_input(hover)
		camera._process(1.0/60.0)
		hover_motion = maxf(hover_motion, Vector2(camera.h_offset,camera.v_offset).length())
	expect(hover_motion > .02, "Hovering and open settings do not suppress idle sway")
	scene._request_menu_close()
	for frame: int in 120:
		var motion := InputEventMouseMotion.new()
		motion.relative = Vector2(1,0)
		motion.button_mask = MOUSE_BUTTON_MASK_MIDDLE
		root.push_input(motion)
		camera._process(1.0/60.0)
	expect(Vector2(camera.h_offset,camera.v_offset).length()<.0001, "Zero delay still respects continuous activity")
	for frame: int in 600: camera._process(1.0/60.0)
	before = Vector2(camera.h_offset,camera.v_offset)
	scene._focus_field(0)
	expect(Vector2(camera.h_offset,camera.v_offset) == before, "Field focus starts without offset snap")
	camera.set_process(true)
	await create_timer(1.2).timeout
	expect(camera.focused and camera.focus_point.distance_to(camera._anchor)<.001, "Field focus reaches intended target with sway enabled")
	camera.configure_sway(false,30)
	await create_timer(2).timeout
	expect(Vector2(camera.h_offset,camera.v_offset).length()<.0001, "Disable settles to stable framing")
	scene._return_overview()
	await create_timer(1).timeout
	# A fast wheel burst belongs entirely to the focus-return gesture.
	camera.zoom(-3)
	await create_timer(1).timeout
	var return_point: Vector3 = camera.focus_point
	var return_view: Vector3 = camera.view
	scene._focus_field(0)
	await create_timer(.85).timeout
	scene._focus_field(1)
	await create_timer(.85).timeout
	scene.selected_tool = "sow"
	for tick: int in 30:
		var back := InputEventMouseButton.new()
		back.pressed = true
		back.button_index = MOUSE_BUTTON_WHEEL_DOWN
		back.factor = 20
		back.position = Vector2(800,400)
		root.push_input(back)
		await create_timer(.035).timeout
	await create_timer(.5).timeout
	expect(not camera.focused and camera.view.is_equal_approx(return_view) and camera.focus_point.is_equal_approx(return_point), "Fast wheel burst restores exact original framing after chained focus, without zoom")
	var ordinary := InputEventMouseButton.new()
	ordinary.pressed = true
	ordinary.button_index = MOUSE_BUTTON_WHEEL_DOWN
	ordinary.position = Vector2(800,400)
	root.push_input(ordinary)
	await create_timer(.8).timeout
	expect(camera.view.z > return_view.z + .7, "Fresh wheel gesture resumes ordinary zoom after return")
	scene._open_menu()
	scene.game_menu._developer_buttons.sway_tuning.pressed.emit()
	await create_timer(1).timeout
	expect(scene.sway_tuning.visible and camera.sway_preview and not camera.sway_enabled, "Developer preview works without changing saved enable preference")
	scene.sway_tuning._sliders.amplitude.value = 0
	await create_timer(2).timeout
	expect(absf(camera.h_offset) < .0001 and absf(camera.v_offset) < .0001, "Live amplitude control can settle motion to zero")
	scene.sway_tuning._sliders.amplitude.value = 1
	await shot("handheld-tuning.png")
	scene.sway_tuning.hide()
	expect(not camera.sway_preview, "Closing tuning ends its preview override")
	await create_timer(2).timeout
	var front: Node3D = scene.find_child("PathLanternFront",true,false)
	expect(front != null and front.find_children("*","MeshInstance3D",true,false).is_empty(), "Foreground lamp and pole removed")
	expect(is_equal_approx(front.get_node("GardenFillLight").omni_range, 5.6), "Field illumination footprint retained")
	scene.atmosphere.set_preview_hour(21)
	await shot("night.png")
	camera.preview_overview({"yaw":-12.0,"pitch":20.0,"distance":25.5,"fov":36.0,"target_x":.25,"target_y":.75,"target_z":0.0})
	await shot("night-left.png")
	camera.preview_overview({"yaw":68.0,"pitch":20.0,"distance":25.5,"fov":36.0,"target_x":.25,"target_y":.75,"target_z":0.0})
	await shot("night-right.png")
	scene.atmosphere.set_preview_hour(12)
	await shot("day.png")
	print("CAMERA_SWAY_TEST failures=%d %s" % [failures.size(),str(failures)])
	scene.queue_free()
	await process_frame
	await process_frame
	quit(0 if failures.is_empty() else 1)

func shot(filename: String) -> void:
	await create_timer(.4).timeout
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(output.path_join(filename))
