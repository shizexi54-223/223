extends SceneTree
## Formal-scene visual evidence at the exact reference dimensions, isolated from player saves.

const Farm = preload("res://farm/farm_state.gd")
const Crops = preload("res://art/crops/crop_visual_catalog.gd")
var scene: Node3D
var captures: String = ""
var failures: Array[String] = []
var checks: int = 0
var now: float = 1800000000.0


func _initialize() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--screenshots="):
			captures = argument.trim_prefix("--screenshots=")
	_run.call_deferred()


func _run() -> void:
	if captures.is_empty():
		push_error("An isolated screenshot destination is required.")
		quit(1)
		return
	DirAccess.make_dir_recursive_absolute(captures)
	root.size = Vector2i(1680, 941)
	scene = load("res://scenes/main.tscn").instantiate()
	scene.clock = func() -> float: return now
	scene.store = load("res://farm/farm_store.gd").new(captures.path_join("save-%d" % Time.get_ticks_usec()))
	scene.settings_store = load("res://settings/settings_store.gd").new(scene.store.directory.path_join("preferences"))
	root.add_child(scene)
	await physics_frame
	_set_hour(12.0)
	await create_timer(1.25).timeout
	await _capture("01-initial-day.png")
	var data: Dictionary = scene.farm_state.snapshot()
	for index in 6:
		for cell_index: int in Farm.CELL_IDS.size():
			var cell: Dictionary = data.fields[Farm.FIELD_IDS[index]].cells[Farm.CELL_IDS[cell_index]]
			var visual_index: int = (index + cell_index) % 6
			cell.crop_id = "greens" if visual_index < 3 else "radish"
			cell.growth_seconds = [0.0, 0.6, 1.0][visual_index % 3] * (1800.0 if visual_index < 3 else 5400.0)
			cell.watered = false
	_expect(scene.farm_state.restore_snapshot(data), "Six-stage fixture obeys production state schema")
	scene.refresh_farm()
	await _capture("02-all-six-stages.png")
	for index in 6:
		var body: StaticBody3D = scene.farm.fields[index]
		var field: Dictionary = scene.farm_state.get_field(Farm.FIELD_IDS[index])
		var plants: Node3D = body.get_node("Crops")
		_expect(plants.get_child_count() == 16 and body.get_meta("field_id") == field.id, "Stable field identity with sixteen independently grouped plants")
		for cell_id: String in Farm.CELL_IDS:
			var cell: Dictionary = field.cells[cell_id]
			var plant: Node3D = plants.get_node(NodePath(cell_id))
			_expect(plant.scene_file_path == Crops.scene_path(cell.crop_id, cell.stage) and plant.scale == Vector3.ONE, "Correct mixed-cell formal stage resource at authored meter scale")
			var anchor: float = scene.farm.FIELD_SIZE.y / 2.0 + scene.farm.TilledSoil.height_at(Vector2(plant.position.x, plant.position.z)) - .008
			_expect(is_equal_approx(plant.position.y, anchor - Crops.planting_depth(cell.crop_id, cell.stage)), "Formal crop follows the continuous soil surface and species planting depth")
		# Stop inside the shallow soil body; the former crop-height collider is gone.
		var point: Vector3 = body.global_position
		var ray := PhysicsRayQueryParameters3D.create(scene.camera.global_position, point, 1)
		_expect(scene.get_world_3d().direct_space_state.intersect_ray(ray).get("collider") == body, "Field collision remains independent of stage mesh")
	# Compare the same composition at full crop density without changing first-save defaults.
	var mature: Dictionary = data.duplicate(true)
	for index in 6:
		for cell: Dictionary in mature.fields[Farm.FIELD_IDS[index]].cells.values():
			cell.growth_seconds = 1800.0 if cell.crop_id == "greens" else 5400.0
	_expect(scene.farm_state.restore_snapshot(mature), "Maximum-density visual fixture preserves the farm schema")
	scene.refresh_farm()
	await _capture("02b-all-mature.png")
	_set_hour(16.5)
	await create_timer(1.0).timeout
	await _capture("02c-golden-hour.png")
	await create_timer(3.0).timeout
	await _capture("02d-golden-hour-motion.png")
	_set_hour(12.0)
	_expect(scene.farm_state.restore_snapshot(data), "Restore the six-stage fixture after maximum-density comparison")
	scene.refresh_farm()
	for index in [0, 2, 3, 5]:
		scene._focus_field(index)
		await create_timer(0.85).timeout
		await _capture("03-focus-%02d.png" % (index + 1))
	scene.camera.drag(Vector2(-300, 160), false)
	scene.camera.drag(Vector2(800, 800), true)
	scene.camera.zoom(-100)
	await create_timer(0.35).timeout
	await _capture("04-focus-limit.png")
	scene._reset_view()
	await create_timer(0.85).timeout
	scene.camera.drag(Vector2(600, -600), false)
	scene.camera.zoom(100)
	await create_timer(0.35).timeout
	await _capture("05-overview-limit.png")
	scene._reset_view()
	await create_timer(0.85).timeout
	_set_hour(21.0)
	await _capture("06-night.png")
	for failure: String in failures:
		push_error(failure)
	print("COMPLETE_SCENE_TEST checks=%d failures=%d screenshots=%s" % [checks, failures.size(), captures])
	root.remove_child(scene)
	scene.free()
	await process_frame
	quit(0 if failures.is_empty() else 1)


func _capture(filename: String) -> void:
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	_expect(root.get_texture().get_image().save_png(captures.path_join(filename)) == OK, "Write formal-scene evidence")


func _set_hour(hour: float) -> void:
	scene.atmosphere.set_preview_hour(hour)


func _expect(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)
