# 远山与河岸背景

## expanded-v5：20260921 左右扩景十张独立素材

按用户要求新增十次独立 image_gen 调用，原生透明 PNG 为 `hill-01..10.png`，不是将同一幅大图切成十份；与 v4 三张共同使用。形态包括单峰、双峰、石坡、低林岸和偏斜山肩。固定参考仍为 v3 的 `west-shoulder.png`，完整提示词、原输出路径、尺寸、alpha范围和用于去透明留白的UV边界见 [expanded-v5/generation-record.json](expanded-v5/generation-record.json)。原图无修改复制到 `Game/art/environment/backdrop/expanded-v5/`，开启 mipmaps；工具没有返回模型、种子或费用。本轮没有新增 Tripo／Blender 调用。

十张图各用一次，分布方位 -108° 至 58°，距离100–240米；与原有三张交错叠加，覆盖普通全景偏航 -12° 至 68° 的两侧视野。几何、透明轮廓与昼夜同步仍沿用 v4。不是可环游山体，不扩展游玩或建设范围。

配套前景在固定世界位置增加六处香蒲与荷叶组合，固定随机种子控制尺寸和朝向，保留中央水道。前景专用网格从原始高档表面构造，不复制导入LOD，原资产及其他场景LOD不改；植物与岸石使用同一不透明覆盖淡出，避免聚焦第一帧切换透明管线和随后改变几何细节。逐帧聚焦截图、左右极限与昼夜／拍照证据位于 `.local/verification/overview-expanded-v5/`，入口 `tests/foreground_composition_test.gd`；方向天空专项沿用 `tests/landscape_sky_test.gd`。

## 现役 individual-v4：20260921 独立工笔小山组合

用户指出 v3 三维山包轮廓过于光滑，与远山绘景不一致。现保留 v3 无限远方向天空，将四段参数化岸坡降到 1.4–1.8 米设计高度，仅承接湖面；较高的山体改用三个分别生成的透明素材，各使用一次，不复用一张大图裁成多座山。

- `single-peak.png`：不对称单峰，岩层与树丛完整，位于方位 -48°／半径142米。
- `twin-hills.png`：矮双峰与宽山鞍，位于 -6°／125米。
- `wooded-knoll.png`：低林岸与小岩丘，位于 -28°／100米。

均由内置 image_gen 以 v3 `west-shoulder.png` 为笔触参考独立生成，1536×1024 原生 RGBA；原图无修改复制到 `Game/art/environment/backdrop/individual-v4/`，保留 alpha、开启 mipmaps。完整实际提示词及输出落点见 [individual-v4/generation-record.json](individual-v4/generation-record.json)。模型版本、种子与费用未返回；本轮没有 Tripo 或 Blender 调用。原始 RGB 在透明像素下包含模糊色彩，alpha 检查确认外围透明，不将预览黑底上的色彩误当实际外发光。

`layered_landscape.gd` 以 UV 去透明留白、保持主体比例，放到固定世界位置的弧形竖直支撑面；不跟随镜头旋转或倾斜。底部贴合共同水位，在低空雾中衔接低矮三维岸脚。`painted_hill.gdshader` 保留绘画明暗，并与天空同步昼夜色；透明轮廓使用深度预通道，避免遮住后景。此方法适用于当前有限活动范围，山体仍是有方位的绘景，不是可绕到背后探索的完整三维模型。

Godot 4.7.2 的材质参数写入不会自动发出 `Resource.changed`；昼夜控制器写完整组天空参数后显式通知一次，由山景同步着色，测试直接检查夜间一致性。[官方空间着色器文档](https://docs.godotengine.org/en/4.7/tutorials/shaders/shader_reference/spatial_shader.html)用于核对透明深度预通道与独立雾处理。

复核入口沿用 `tests/landscape_sky_test.gd`（新增低岸高度、山片不跟随相机、夜间颜色）及 `tests/foreground_composition_test.gd -- --output=<仓库绝对路径>/.local/verification/individual-hills-v4`。后者保留实际农场的默认、侧向、俯仰、拍照、昼夜、聚焦与窗口尺寸截图。下述 v3 的高山岸已退役，方向天空与湖面仍沿用。

## horizon-v3：20260921 方向天空与真实山岸（高山岸已替换）

背景改为 Godot `Sky` 方向投影：三张独立透明山图分别覆盖不同方位，每种只使用一次，以视线方位角和仰角采样。转动镜头自然看到另一段山景，平移不产生无限远背景的视差；不再存在随相机倾斜的有限山卡或底板。远山属于无限远绘景，不代表可到达的三维山脉。[Godot 官方天空着色器文档](https://docs.godotengine.org/en/stable/tutorials/shaders/shader_reference/sky_shader.html)说明 `EYEDIR` 和环境光立方体通道；项目在 Godot 4.7.2 实测。

内置 image_gen 以已批准的青菜、全景两图为风格参考，分别生成左高右低山肩、右侧双峰和低矮连绵丘陵，三张均为 2172×724 原生 RGBA。原件与完整实际提示词见 [horizon-v3/generation-record.json](horizon-v3/generation-record.json)，源图保存在同目录；正式图原样复制到 `Game/art/environment/backdrop/horizon-v3/`，开启 mipmaps，运行时过滤低 alpha 彩边。未调用 Tripo 或 Blender；图片工具未返回模型版本、种子和费用，不自行推算。

中远处四段山岸由 `Game/scenes/environment/layered_landscape.gd` 生成真实起伏网格，共 11,520 三角形，采用共同的淡彩材质；岸线起始半径 78–95 米，岸脚低于 y=-0.25 的共同水位。岛、岸、湖面使用同一世界坐标，平移、俯仰和遮挡由实际透视决定。2000×2000 米水面延伸至岸下，远裁面前渐入地平线色，不再在 72 米截断露出另一张画。低空雾随高度减弱；引擎深度雾仅在 160–400 米收尾，避免把山岸重复蒙成平色。

天空、环境光、山岸、雾及水面反射色跟随同一昼夜控制器。水面使用柔化天空色，未增加精确山体镜面反射。默认全景调整为偏航 27.5°、俯角 10°、距离 25.5、视野 36°，保留田块清晰带，并为真实地平线留下画面空间。

验证入口：`tests/landscape_sky_test.gd` 检查方向投影、平移不产生天空视差、远裁面不裁天空、±180° 连续性与山岸体积／法线；`tests/foreground_composition_test.gd -- --output=<仓库绝对路径>/.local/verification/landscape-v3` 覆盖旋转、俯仰、真实拍照像素、聚焦、画质、昼夜、小窗和 4K。截图分别在 `.local/verification/landscape-sky/`、`.local/verification/landscape-v3/`。旧图和旧记录作为历史来源保留，下述山卡流程已退役。

## 历史 layers-v2：20260918 去重复与岛村层次

新生成三张独立原生RGBA：`far-west.png`左高峰长谷、`far-east.png`右侧宽峰、`wooded-bank.png`低矮林岸。每张只出现一次，不翻转／平铺复制；完整提示词和工具落点见[layers-v2/generation-record.json](layers-v2/generation-record.json)，正式PNG原样复制到`Game/art/environment/backdrop/layers-v2/`，保留alpha并开启mipmaps。

舞台仍为2.5D远景，三块细分支撑面在不同深度，边缘做小幅静态弯曲；宽度与高度分别控制远山和低岸的屏幕尺度，不沿用旧版的固定3:1几何比例。西山(-102,105,-400)、东山(113,100,-365)、林岸(0,63,-275)；对应尺寸320×75、310×80、380×30，加天空／薄雾共五块。昼夜色彩同步保留；2026-09-21 起舞台只跟随明确修改的全景调节基准，不再跟随实时偏航，否则左右转动会被抵消、背景像贴在屏幕上。上下俯仰和左右转动都通过真实投影改变画面位置；图片左右各8%的透明度渐隐到共同雾色，避免极限侧视角露出原图竖直截边；无图案的天空／远水底色单独跟随偏航以始终覆盖画面，山岸图片不跟随；避免有限底板的侧边和远裁切露出竖缝。不能将绘景称为可环游的真实山脉。

远岸带上移并缩小树木高度，为[真实三维邻居岛](../Islets/README.md)留下湖面。后续[岛群续改](../Archipelago/README.md)将真实水面由10–18米延至48–72米过渡，并同步上移水／天底色过渡，填补暖灰断层；仍需检查倾斜山卡不能被扩展水面遮住。远岛水下部分按共同水位裁掉，避免在绘景水域露底。旧图与首轮证据保留，不覆盖。统一验证及视频入口见岛群记录。

同日水雾续修：绘景湖面不再按屏幕高度单独混合水色，而是计算视线与虚拟水面的交点距离，使用与真实湖面共同的雾起止距离和密度，避免白／蓝／白分带。山岸绘景也响应雾气滑块；素材自带薄雾保留。根因、真实水面深度写入及4K定向证据见[开发记录](../../../docs/development-setup.md#水雾与景深连续性修复2026-09-18)。本轮没有重新生成图片。

## 历史 layers-v1（已被上述三张独立轮廓替换）

首版使用 `layers-v1/` 三张原生透明 PNG，由内置 **image_gen** 分别生成。按顺序输入已批准的 `farm-gongbi-v1.png`（全景风格）和 `greens-gongbi-v1.png`（形体／笔触质感）作为参考。实际提示词、参考顺序与工具原始落点见 [generation-record.json](layers-v1/generation-record.json)。工具未返回具体模型版本、种子及费用，该轮未调用 Tripo。

| 文件 | 内容 | 原始尺寸 |
|---|---|---|
| `far-mountains.png` | 冷灰青远山轮廓 | 2172×724 RGBA |
| `mid-hills.png` | 中景丘陵与林木 | 2172×724 RGBA |
| `near-bank.png` | 柳岸、小民居与石桥 | 2172×724 RGBA |

源图完整保留工具生成的 alpha，原样复制到 `Game/art/environment/backdrop/layers-v1/`。没有用白底抠图、棋盘格假透明或代码重画。生成图极低 alpha 像素含无意义的鲜亮 RGB；运行材质舍弃 alpha<0.025 的像素，并平滑收实主体透明度，避免薄边漏色。Godot 导入保留 alpha border 修复并开启 mipmaps，实际全景、近景与昼夜检查无彩色光边。

`Game/scenes/environment/layered_landscape.gd` 将素材按原始3:1比例放在平面上：舞台局部 Z 为 −380、−310、−240，分别横向排列3、5、7段，保留小尺度山岸、连续宽远景；−270 层为缓慢流动的程序薄雾，−460 为无贴图天空／远水底色。共17块四边形、34三角形，共用一个材质。

舞台保持适合俯视微缩场景的固定俯角，每帧在相机更新后同步偏航，使岸线水平；没有缓动追随、滚动图片 UV 或圆柱重投影。它是2.5D绘画舞台，不是可环游的固定三维山脉。早期固定倾斜舞台在侧面会产生斜岸线，且单张素材铺得过大，已按用户反馈替换。1200×700 的底板与相机600米远裁面覆盖已测合法镜头边界；修改镜头范围时须复查背景覆盖与岸线水平，不能只看默认全景。

水面本身仍是水平网格，远处按观察方向的平面纵深10–18米淡出，移除原围岛圆形淡出带，避免两侧先露底造成弯曲湖面的错觉。昼夜控制器同步山景、天空、远水与雾色；傍晚降低背景亮度并转冷，夜间继续变暗。山岸各层以不同程度混入雾色，再由实际景深虚化。它们不承担碰撞或建筑交互，主岛、田块、房屋与船桥仍为真实3D，菜地清晰带按实际相机深度计算。
旧 `river-distance.png` 和原源图保留，现只以低权重作为近水淡彩底色采样，不再承载远景。原环形单图方案见 [历史水面与远景交接](../../../docs/task/首个可发布版本/handoffs/3.4-visual-refinement-handoff.md)，其中投影方法不再适用于当前版本。
